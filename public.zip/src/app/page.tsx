import React from 'react';

import {
  filterDataByKey,
  reverseFilterDataByKey,
} from '@/shared/utils/pageHelpers/filterData.helper';

import {
  HeroSection,
  AboutSection,
  BoardMember,
  AnnuallyServe,
  MicroHealthSection,
  StoriesSection,
  SevenPrinciple,
} from '@/components/Home';

import {
  ServiceSection,
  WorkTogether,
  AnnualReportSection,
} from '@/shared/components';
import VideoSection from '@/components/Home/videoSection/index.blade';
import useFetchLaravelData from '@/shared/hook/useFetchData/useFetchData';
import NewsEventSection from '@/components/Home/newsEventSection/NewsEventSection';
import JourneySection from '@/components/Home/journeySection/JourneySection';
import AnnualImpactSection from '@/components/Home/AnnualImpactSection/AnnualImpactSection';

const Home = async () => {
  const homePageContentData = await useFetchLaravelData({ url: '/home-contents' });
  const homeNewPageContentData = await useFetchLaravelData({ url: '/home-contents' });

  const summeryReportData = await useFetchLaravelData({
    url: '/summary-report-settings/basic',
  });
  // const sliderImages = await useFetch({ url: '/home-slider-content' });
  const sliderImages = await useFetchLaravelData({ url: '/home-slider-contents' });

  const storyCategory = await useFetchLaravelData({ url: '/story-categories' });
  const serviceContent = await useFetchLaravelData({ url: '/service-contents/home' });

  const heroSliderImages = sliderImages?.data;
  const badgeImage = homePageContentData?.badge_image;
  const workTogetherImage = homePageContentData?.work_together_image;
  const annuallyServeImage = homePageContentData?.annually_serve;
  const aboutSectionData = {
    title: homePageContentData?.intro_title,
    subTitleOne: homePageContentData?.intro_sub_title_one,
    subTitleTwo: homePageContentData?.intro_sub_title_two,
  };

  // const boardMemberArray = [
  //   {
  //     id: 1,
  //     name: homePageContentData?.chairman_name,
  //     description: homePageContentData?.chairman_speech,
  //     designation: homePageContentData?.chairman_designation,
  //     image: homePageContentData?.chairman_thumb_image,
  //     reverse: false,
  //   },
  //   {
  //     id: 2,
  //     name: homePageContentData?.md_name,
  //     description: homePageContentData?.md_speech,
  //     designation: homePageContentData?.md_designation,
  //     image: homePageContentData?.md_thumb_image,
  //     reverse: true,
  //   },
  // ];
  const boardMemberArray = [
    {
      id: 1,
      name: homeNewPageContentData?.chairman_name,
      description: homeNewPageContentData?.chairman_speech,
      designation: homeNewPageContentData?.chairman_designation,
      image: homeNewPageContentData?.chairman_thumb_image,
      reverse: false,
    },
    {
      id: 2,
      name: homeNewPageContentData?.md_name,
      description: homeNewPageContentData?.md_speech,
      designation: homeNewPageContentData?.md_designation,
      image: homeNewPageContentData?.md_thumb_image,
      reverse: true,
    },
  ];

  const annuallyWeServeData = filterDataByKey(
    summeryReportData?.data,
    'annually_we_serve'
  );
  const annuallyReportData = reverseFilterDataByKey(
    summeryReportData?.data,
    'annually_we_serve'
  );

  const microHealthData = homePageContentData?.mhi_banner_image;

  return (
    <>
      <HeroSection badgeImage={badgeImage} sliderImages={heroSliderImages} />
      <NewsEventSection />
      <VideoSection />
      <JourneySection about={aboutSectionData} serviceData={serviceContent.data} />


      {/* <AboutSection data={aboutSectionData} />
      <ServiceSection serviceData={serviceContent.data} /> */}

      <BoardMember memberData={boardMemberArray} />
      <AnnualImpactSection
        serveData={annuallyWeServeData}
        data={annuallyReportData}
        image={annuallyServeImage}
      />
      {/* <AnnuallyServe data={annuallyWeServeData} />
      <AnnualReportSection data={annuallyReportData} headingText="Annual" /> */}
      <MicroHealthSection image={microHealthData} />
      <SevenPrinciple />
      <StoriesSection storyCategory={storyCategory.data} />
      <WorkTogether image={workTogetherImage} />
    </>
  );
};

export default Home;
