import React from 'react';

import {
  HeroSection,
  TeamGrid,
  TeamGroup,
  WorkTogether,
} from '@/shared/components';
import { PeopleCulture } from '@/components/Corporate';
import { filterDataByDepartment } from '@/shared/utils/pageHelpers/filterData.helper';
import useFetchLaravelData from '@/shared/hook/useFetchData/useFetchData';

const Corporate = async () => {
  const bannerData = await useFetchLaravelData({ url: '/banners/corporate' });
  const corporate = await useFetchLaravelData({ url: '/peoples' });
  const homePageContentData = await useFetchLaravelData({ url: '/home-contents' });

  const filterManagementData = filterDataByDepartment(
    corporate?.data,
    'Management'
  );
  const filterAccountAndFinanceData = filterDataByDepartment(
    corporate?.data,
    'Account & Finance'
  );
  const filterHumanResourceData = filterDataByDepartment(
    corporate?.data,
    'Human Resources'
  );
  const filterAdministration = filterDataByDepartment(
    corporate?.data,
    'Administration'
  );
  const filterServicesAndProcurementData = filterDataByDepartment(
    corporate?.data,
    'Services & Procurement'
  );
  const filterAuditData = filterDataByDepartment(
    corporate?.data,
    'Audit & Internal Compliance'
  );
  const filterBrandingAndSecretariatData = filterDataByDepartment(
    corporate?.data,
    'Secretariat Research & Communications'
  );
  const filterMarketingOperationsAndMonitoringData = filterDataByDepartment(
    corporate?.data,
    'Marketing, Operations & Monitoring'
  );
  const filterTrainingData = filterDataByDepartment(
    corporate?.data,
    'Training'
  );
  const filterTechnologyData = filterDataByDepartment(
    corporate?.data,
    'Information Technology (IT)'
  );

  // API te banner na thakle ei fallback image dekhabe
  const bgHero =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1693472682/MicrosoftTeams-image_80_wmqvsd.png';
  const managementImg =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1692608043/management-leadership-_1__cnt3vv.jpg';
  const accountImg =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1692608043/account-finance_apn4ac.jpg';
  const hrImg =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1692608044/resource-full_yrklg7.jpg';
  const servicesImg =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1692608042/procurement_gocoxd.jpg';
  const auditImg =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1692608042/audit-internal_bdrn5d.jpg';
  const brandingImg =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1692608043/brand-full_rpfuxj.jpg';
  const trainingImg =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1692608043/training_section_banner_mukpax.jpg';
  const itImg =
    'https://res.cloudinary.com/dboyf6lad/image/upload/v1692608043/information_technology_section_banner_t3wy0u.jpg';

  const workTogetherImage = homePageContentData?.work_together_image;

  return (
    <>
      <HeroSection
        titleOne="Serving Bottom of the"
        titleTwo="Pyramid with Utmost"
        titleThree="Care and Sincerity"
        backgroundImage={bannerData?.data?.banner || bgHero}
        title={bannerData?.data?.title}
        subtitle={bannerData?.data?.subtitle}
      />
      <PeopleCulture />
      <TeamGroup
        headingTextOne="Management"
        headingTextTwo="Leadership"
        image={managementImg}
      />
      <TeamGrid datas={filterManagementData} />
      <TeamGroup
        headingTextOne="Accounts & Finance"
        marginTop
        image={accountImg}
      />
      <TeamGrid datas={filterAccountAndFinanceData} />
      <TeamGroup headingTextOne="Human Resources" marginTop image={hrImg} />
      <TeamGrid datas={filterHumanResourceData} />
      <TeamGroup headingTextOne="Administration" marginTop image={hrImg} />
      <TeamGrid datas={filterAdministration} />
      <TeamGroup
        headingTextOne="Services & Procurement"
        marginTop
        image={servicesImg}
      />
      <TeamGrid datas={filterServicesAndProcurementData} />
      <TeamGroup
        headingTextTwo="Audit & Internal Compliance"
        marginTop
        image={auditImg}
      />
      <TeamGrid datas={filterAuditData} />
      <TeamGroup
        headingTextOne="Marketing, Operations & Monitoring"
        marginTop
        image={brandingImg}
      />
      <TeamGrid datas={filterMarketingOperationsAndMonitoringData} />
      <TeamGroup
        headingTextOne="Secretariat, Research and Communications"
        marginTop
        image={brandingImg}
      />
      <TeamGrid datas={filterBrandingAndSecretariatData} />
      <TeamGroup headingTextTwo="Training" marginTop image={trainingImg} />
      <TeamGrid datas={filterTrainingData} />
      <TeamGroup
        headingTextTwo="Information Technology (IT)"
        marginTop
        image={itImg}
      />
      <TeamGrid datas={filterTechnologyData} />
      <WorkTogether image={workTogetherImage} />
    </>
  );
};

export default Corporate;